#!/bin/bash
echo "Installing Swipe..."
echo "Requires root privileges to install to /opt/swipe"

if [ "$EUID" -ne 0 ]; then 
  echo "Please run as root (sudo ./install.sh)"
  exit 1
fi

# 1. Install Files
mkdir -p /opt/swipe
cp -r ./* /opt/swipe/
chmod +x /opt/swipe/swipe
ln -sf /opt/swipe/swipe /usr/local/bin/swipe

# 2. Desktop Integration
echo "Configuring Desktop Shortcut..."
ICON_SRC="/opt/swipe/data/flutter_assets/assets/icon.png"
DESKTOP_SRC="/opt/swipe/swipe.desktop"

# Ensure icon exists (if not, use a placeholder or skip)
if [ ! -f "$ICON_SRC" ]; then
     echo "Warning: Icon not found at $ICON_SRC"
fi

# Install .desktop file
if [ -f "$DESKTOP_SRC" ]; then
     cp "$DESKTOP_SRC" /usr/share/applications/
     chmod 644 /usr/share/applications/swipe.desktop
else
     echo "Warning: swipe.desktop not found in package"
fi

echo "Installation Complete!"
echo "Run 'swipe' from your application menu or 'sudo swipe' in terminal."
